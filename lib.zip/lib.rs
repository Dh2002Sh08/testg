use anchor_lang::prelude::*;
use anchor_spl::token::{self, Token, TokenAccount, Transfer};

declare_id!("Afo3KtirMBS6UJjoiCe4E5KhxnuCqK1orRe7PtGZVtfh");

#[program]
pub mod staking {
    use super::*;

    pub fn initialize(ctx: Context<Initialize>) -> Result<()> {
        let staking_account = &mut ctx.accounts.staking_account;
        staking_account.owner = ctx.accounts.user.key();
        staking_account.total_staking = 0;
        Ok(())
    }

    pub fn stake(ctx: Context<Stake>, amount: u64) -> Result<()> {
        let user_stake = &mut ctx.accounts.user_stake;
        let staking_account = &mut ctx.accounts.staking_account;

        require!(amount > 0, StakingError::InvalidAmount);

        let transfer_instruction = Transfer {
            from: ctx.accounts.user_token_account.to_account_info(),
            to: ctx.accounts.staking_account_token.to_account_info(),
            authority: ctx.accounts.user.to_account_info(),
        };

        let transfer_ctx = CpiContext::new(
            ctx.accounts.token_program.to_account_info(),
            transfer_instruction,
        );

        token::transfer(transfer_ctx, amount)?;

        user_stake.owner = ctx.accounts.user.key();
        user_stake.amount += amount;

        staking_account.total_staking += amount;

        Ok(())      
    }

    pub fn unstake(ctx: Context<Unstake>, amount: u64) -> Result<()> {
        let user_stake = &mut ctx.accounts.user_stake;

        require!(user_stake.amount >= amount, StakingError::NothingToStake);

        // ✅ Store immutable reference **before** mutable borrow
        let staking_account_info = ctx.accounts.staking_account.to_account_info();
        let user_key = ctx.accounts.user.key();
        let bump = ctx.bumps.staking_account;

        let seeds: &[&[u8]] = &[b"staking", user_key.as_ref(), &[bump]];
        let signer = &[&seeds[..]];

        let transfer_instruction = Transfer {
            from: ctx.accounts.staking_account_token.to_account_info(),
            to: ctx.accounts.user_token_account.to_account_info(),
            authority: staking_account_info, // ✅ Use stored reference
        };

        let transfer_ctx = CpiContext::new_with_signer(
            ctx.accounts.token_program.to_account_info(),
            transfer_instruction,
            signer,
        );

        token::transfer(transfer_ctx, amount)?;

        // ✅ Now safe to mutate staking_account
        let staking_account = &mut ctx.accounts.staking_account;
        staking_account.total_staking -= amount;
        user_stake.amount -= amount;

        if user_stake.amount == 0 {
            ctx.accounts
                .user_stake
                .close(ctx.accounts.user.to_account_info())?;
        }

        Ok(())
    }
}

#[derive(Accounts)]
pub struct Initialize<'info> {
    #[account(
        init_if_needed,
        payer = user,
        space = 8 + 40,
        seeds = [b"staking", user.key().as_ref()],
        bump,
    )]
    pub staking_account: Account<'info, StakingAccount>,

    #[account(mut)]
    pub user: Signer<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct Stake<'info> {
    #[account(mut)]
    pub staking_account: Account<'info, StakingAccount>,

    #[account(
        mut,
        seeds = [b"user_stake", user.key().as_ref()],
        bump
    )]
    pub user_stake: Account<'info, UserStake>,

    #[account(mut)]
    pub user_token_account: Account<'info, TokenAccount>,
    #[account(mut)]
    pub staking_account_token: Account<'info, TokenAccount>,

    #[account(mut)]
    pub user: Signer<'info>,
    pub token_program: Program<'info, Token>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct Unstake<'info> {
    #[account(
        mut,
        seeds = [b"staking", user.key().as_ref()],
        bump,
    )]
    pub staking_account: Account<'info, StakingAccount>,

    #[account(
        mut, 
        close = user,
        seeds = [b"user_stake", user.key().as_ref()],
        bump,
    )]
    pub user_stake: Account<'info, UserStake>,

    #[account(mut)]
    pub user_token_account: Account<'info, TokenAccount>,

    #[account(mut)]
    pub staking_account_token: Account<'info, TokenAccount>,

    #[account(mut)]
    pub user: Signer<'info>,

    pub token_program: Program<'info, Token>,
}

#[account]
pub struct StakingAccount {
    pub owner: Pubkey,
    pub total_staking: u64,
}

#[account]
pub struct UserStake {
    pub owner: Pubkey,
    pub amount: u64,
    pub bump: u8,
}

#[error_code]
pub enum StakingError {
    #[msg("Invalid staking amount. Must be greater than zero.")]
    InvalidAmount,

    #[msg("You have Nothing to Unstake")]
    NothingToStake,

    #[msg("You are not the Owner")]
    InvalidOwner,
}
