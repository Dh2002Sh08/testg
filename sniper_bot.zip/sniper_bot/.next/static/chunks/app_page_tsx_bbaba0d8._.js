(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_dist_compiled_204e67f4._.js",
  "static/chunks/node_modules_pako_dist_pako_esm_mjs_b4dc27e5._.js",
  "static/chunks/node_modules_@project-serum_anchor_dist_browser_index_330d9689.js",
  "static/chunks/node_modules_@solana_spl-token_lib_esm_7e897c2c._.js",
  "static/chunks/node_modules_@solana_bb33b31e._.js",
  "static/chunks/node_modules_77e4ac75._.js",
  "static/chunks/_3909133f._.js"
],
    source: "dynamic"
});
