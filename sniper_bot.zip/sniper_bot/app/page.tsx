import Liquidity from '@/components/liquidity'
import React from 'react'

function page() {
  return (
    <><Liquidity /></>
  )
}

export default page