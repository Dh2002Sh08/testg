"use client";
import React, { useMemo, useState, useCallback } from 'react';
import { WalletMultiButton } from '@solana/wallet-adapter-react-ui';
import { useConnection, useWallet } from '@solana/wallet-adapter-react';
import { AnchorProvider } from '@project-serum/anchor';
import { InitializePool, IntializeVault, swapToken } from '@/utils/useprogram';

const Liquidity: React.FC = () => {
    const [tokenPrice, setTokenPrice] = useState(0);
    const [solAmount, setSolAmount] = useState(0);
    const [isVaultInitialized, setIsVaultInitialized] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [showToast, setShowToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);
    const { connection } = useConnection();
    const { wallet, publicKey, signTransaction, signAllTransactions } = useWallet();

    const provider = useMemo(() => {
        if (!wallet || !publicKey || !signTransaction || !signAllTransactions) return null;
        return new AnchorProvider(
            connection,
            { publicKey, signTransaction, signAllTransactions },
            { commitment: 'processed' }
        );
    }, [wallet, publicKey, signTransaction, signAllTransactions, connection]);

    const showNotification = useCallback((message: string, type: 'success' | 'error') => {
        setShowToast({ message, type });
        setTimeout(() => setShowToast(null), 3000);
    }, []);

    const handleInitializeLiquidity = async () => {
        if (!provider) {
            showNotification("Please connect your wallet", 'error');
            return;
        }

        setIsLoading(true);
        try {
            const lamportsPerToken = tokenPrice * 1e9;
            const vaultTx = await IntializeVault(provider);
            const tx = await InitializePool(provider, lamportsPerToken);
            console.log('Transaction:', tx);
            showNotification('Liquidity initialized successfully!', 'success');
        } catch (error) {
            console.error("Error initializing liquidity:", error);
            showNotification("Error initializing liquidity. Please try again.", 'error');
        } finally {
            setIsLoading(false);
        }
    };

    const handleSwapTokens = async () => {
        if (!provider) {
            showNotification("Please connect your wallet", 'error');
            return;
        }

        setIsLoading(true);
        try {
            const lamports = solAmount * 1e9;
            console.log('Sol Amount:', lamports);
            
            // if (!isVaultInitialized) {
            //     const vaultTx = await IntializeVault(provider);
            //     if (vaultTx) {
            //         setIsVaultInitialized(true);
            //     }
            // }
            
            const tx = await swapToken(provider, lamports);
            showNotification('Tokens swapped successfully!', 'success');
        } catch (error) {
            console.error("Error swapping tokens:", error);
            showNotification("Error swapping tokens. Please try again.", 'error');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 flex items-center justify-center p-4 sm:p-6 lg:p-8">
            <div className="w-full max-w-md space-y-6">
                {/* Initialize Liquidity Card */}
                <div className="relative bg-white rounded-2xl shadow-2xl p-6 sm:p-8 overflow-hidden transform transition-all duration-300 hover:shadow-3xl">
                    <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/10 to-purple-500/10 opacity-0 hover:opacity-100 transition-opacity duration-300"></div>
                    <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900 mb-6 text-center">Initialize Liquidity</h1>
                    
                    <div className="space-y-5">
                        <WalletMultiButton className="w-full !bg-gradient-to-r !from-indigo-600 !to-purple-600 !hover:from-indigo-700 !hover:to-purple-700 !text-white !font-semibold !py-3 !rounded-xl !transition-all !duration-300 !shadow-md" />
                        
                        <div className="relative group">
                            <input
                                type="number"
                                value={tokenPrice}
                                onChange={(e) => setTokenPrice(Number(e.target.value))}
                                placeholder="Token Price in SOL"
                                className="w-full p-3 pl-4 pr-12 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-200 text-gray-700"
                            />
                            <span className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 text-sm font-medium">SOL</span>
                        </div>

                        <button
                            onClick={handleInitializeLiquidity}
                            disabled={!provider || isLoading}
                            className="relative w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-semibold py-3 px-4 rounded-xl transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed overflow-hidden group"
                        >
                            <span className="relative z-10">
                                {isLoading ? 'Processing...' : 'Initialize Liquidity'}
                            </span>
                            <span className="absolute inset-0 bg-white opacity-0 group-hover:opacity-10 transition-opacity duration-300"></span>
                        </button>

                        <p className="text-center text-gray-600 text-sm font-medium">
                            Token Price: <span className="text-indigo-600">{tokenPrice} SOL</span>
                        </p>
                    </div>
                </div>

                {/* Swap Tokens Card */}
                <div className="relative bg-white rounded-2xl shadow-2xl p-6 sm:p-8 overflow-hidden transform transition-all duration-300 hover:shadow-3xl">
                    <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/10 to-purple-500/10 opacity-0 hover:opacity-100 transition-opacity duration-300"></div>
                    <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900 mb-6 text-center">Swap Tokens</h1>
                    
                    <div className="space-y-5">
                        <div className="relative group">
                            <input
                                type="number"
                                value={solAmount}
                                onChange={(e) => setSolAmount(Number(e.target.value))}
                                placeholder="Amount to Swap"
                                className="w-full p-3 pl-4 pr-12 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all duration-200 text-gray-700"
                            />
                            <span className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 text-sm font-medium">SOL</span>
                        </div>

                        <button
                            onClick={handleSwapTokens}
                            disabled={!provider || isLoading}
                            className="relative w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-semibold py-3 px-4 rounded-xl transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed overflow-hidden group"
                        >
                            <span className="relative z-10">
                                {isLoading ? 'Processing...' : 'Swap Tokens'}
                            </span>
                            <span className="absolute inset-0 bg-white opacity-0 group-hover:opacity-10 transition-opacity duration-300"></span>
                        </button>

                        <p className="text-center text-gray-600 text-sm font-medium">
                            Amount to Swap: <span className="text-indigo-600">{solAmount} SOL</span>
                        </p>
                    </div>
                </div>

                {/* Toast Notification */}
                {showToast && (
                    <div className={`fixed bottom-6 right-6 px-6 py-4 rounded-xl shadow-lg text-white flex items-center space-x-2 transform transition-all duration-300 ${showToast.type === 'success' ? 'bg-green-500' : 'bg-red-500'} animate-slide-in`}>
                        <span>{showToast.message}</span>
                        <button onClick={() => setShowToast(null)} className="text-white hover:text-gray-200">
                            ✕
                        </button>
                    </div>
                )}
            </div>

            {/* Custom Tailwind Animations */}
            <style jsx global>{`
                @keyframes slide-in {
                    from {
                        transform: translateY(100px);
                        opacity: 0;
                    }
                    to {
                        transform: translateY(0);
                        opacity: 1;
                    }
                }
                .animate-slide-in {
                    animation: slide-in 0.3s ease-out;
                }
                .shadow-3xl {
                    box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
                }
            `}</style>
        </div>
    );
};

export default Liquidity;