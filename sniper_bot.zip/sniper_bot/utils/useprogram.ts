import { BN, Program, AnchorProvider } from '@project-serum/anchor';
import {
  PublicKey,
  SystemProgram,
  Transaction,
  SYSVAR_RENT_PUBKEY,
  Keypair,
  SendTransactionError,
} from '@solana/web3.js';
import {
  TOKEN_PROGRAM_ID,
  createInitializeAccountInstruction,
  getMinimumBalanceForRentExemptAccount,
  ACCOUNT_SIZE,
  getAssociatedTokenAddress,
  createAssociatedTokenAccountInstruction,
  ASSOCIATED_TOKEN_PROGRAM_ID,
} from '@solana/spl-token';
import { IDL, programId } from './program';

export const PROGRAM_ID = new PublicKey(programId);
// export const VAULT_SEED = 'vault';

// export function getVaultAddress() {
//   return PublicKey.findProgramAddressSync(
//     [Buffer.from(VAULT_SEED)],
//     PROGRAM_ID
//   );
// }

// export const [vaultPda] = getVaultAddress();

export function getProgram(provider: AnchorProvider) {
  return new Program(IDL, PROGRAM_ID, provider);
}

export const InitializePool = async (
  provider: AnchorProvider,
  tokenPerSol: number,
) => {
  const program = getProgram(provider);

  const [poolState] = PublicKey.findProgramAddressSync(
    [Buffer.from('pool-state'), provider.wallet.publicKey.toBuffer()],
    PROGRAM_ID
  );
  console.log('Pool State:', poolState.toBase58());
  console.log('Authority:', provider.wallet.publicKey.toBase58());
  try {

    const tx = program.methods
      .initializePool(new BN(tokenPerSol))
      .accounts({
        poolState: poolState,
        authority: provider.wallet.publicKey,
        systemProgram: SystemProgram.programId,
      }).rpc();
    return tx;
  } catch (error) {
    console.error('Error initializing pool:', error);
    throw error;
  }
}

export const swapToken = async (
  provider: AnchorProvider,
  solAmount: number
) => {
  const program = getProgram(provider);

  const [poolState] = PublicKey.findProgramAddressSync(
    [Buffer.from('pool-state'), provider.wallet.publicKey.toBuffer()],
    PROGRAM_ID
  );

  const [vaultPda] = PublicKey.findProgramAddressSync(
    [Buffer.from('vault')],
    PROGRAM_ID
  );
  const tokenMint = new PublicKey("6iawW1Mmh6ikexzQzPojLHfbnVqZkVGovLTP14VxreN6");

  const token_vault = await getAssociatedTokenAddress(
    tokenMint,
    vaultPda,
    true
  );
  console.log('Token Vault:', token_vault.toBase58());

  // if user token not exist, create it
  const user_token_account = await getAssociatedTokenAddress(
    tokenMint,
    provider.wallet.publicKey,
  );
  const userTokenAccountInfo = await provider.connection.getAccountInfo(user_token_account);
  if (!userTokenAccountInfo) {
    console.log('User token account not found, creating it...');
    const tx = new Transaction().add(
      createAssociatedTokenAccountInstruction(
        provider.wallet.publicKey,
        user_token_account,
        provider.wallet.publicKey,
        tokenMint,
      )
    );
    await provider.sendAndConfirm(tx);
  }



  console.log('Pool State:', poolState.toBase58());
  console.log('Authority:', provider.wallet.publicKey.toBase58());
  try {
    const tx = program.methods
      .swap(new BN(solAmount))
      .accounts({
        poolState: poolState,
        vaultAuthority: vaultPda,
        tokenVault: token_vault,
        userTokenAccount: user_token_account,
        tokenMint: tokenMint,
        user: provider.wallet.publicKey,
        tokenProgram: TOKEN_PROGRAM_ID,
        systemProgram: SystemProgram.programId,
      }).rpc();
    return tx;
  } catch (error) {
    console.error('Error swapping token:', error);
    throw error;
  }

  }

export const IntializeVault = async (
  provider: AnchorProvider,
) => {
  const program = getProgram(provider);

  const [vaultPda] = PublicKey.findProgramAddressSync(
    [Buffer.from('vault')],
    PROGRAM_ID
  );
  console.log('VaultPda:', vaultPda.toBase58());
  const tokenMint = new PublicKey("6iawW1Mmh6ikexzQzPojLHfbnVqZkVGovLTP14VxreN6");

  const vaultTokenAccount = await getAssociatedTokenAddress(
    tokenMint,
    vaultPda,
    true
  );
  console.log('Token Vault:', vaultTokenAccount.toBase58());



  // const [poolState] = PublicKey.findProgramAddressSync(
  //   [Buffer.from('pool-state'), provider.wallet.publicKey.toBuffer()],
  //   PROGRAM_ID
  // );

  console.log('Vault:', vaultPda.toBase58());
  // console.log('Pool State:', poolState.toBase58());
  try {
    const tx = program.methods
      .initializeVault()
      .accounts({
        admin: provider.wallet.publicKey,
        vaultAuthority: vaultPda,
        vaultTokenAccount,
        tokenMint: tokenMint,
        systemProgram: SystemProgram.programId,
        tokenProgram: TOKEN_PROGRAM_ID,
        associatedTokenProgram: ASSOCIATED_TOKEN_PROGRAM_ID,
        rent: new PublicKey('SysvarRent111111111111111111111111111111111')
      }).rpc();
    return tx;
  } catch (error) {
    console.error('Error initializing vault:', error);
    throw error;
  }
}